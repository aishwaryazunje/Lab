package newpackage;

public class Cube {
	public static void main(String args[])
	{
		int a=4;
		int volume=a*a*a;
		System.out.println("cube of 4 is="+volume);
	}

}
